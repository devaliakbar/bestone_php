    
<script src="js/jquery.select2.js"></script>    
<script src="js/custom.js"></script>    
</body>
</html>